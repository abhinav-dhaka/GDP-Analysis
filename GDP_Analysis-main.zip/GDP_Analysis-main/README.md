# GDP_Analysis
This project is based on the analysis of GDP of India and its states for last 10 years. I have used the data directly from the MOSPI website.
